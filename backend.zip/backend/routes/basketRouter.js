const express = require('express');
const router = express.Router();
const { Basket, BasketFlower } = require('../models/models');

// Отримання кошика користувача за userId
router.get('/:userId', async (req, res) => {
  try {
    const basket = await Basket.findOne({
      where: { userId: req.params.userId },
      include: [BasketFlower],
    });
    if (!basket)
      return res.status(404).json({ message: 'Basket not found' });
    res.json(basket);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Додавання квітки до кошика (створення нового запису)
router.post('/:userId/flowers', async (req, res) => {
  try {
    const { flowerId, quantity } = req.body;
    let basket = await Basket.findOne({ where: { userId: req.params.userId } });
    if (!basket) {
      basket = await Basket.create({ userId: req.params.userId });
    }
    const basketFlower = await BasketFlower.create({
      basketId: basket.id,
      flowerId,
      quantity,
    });
    res.status(201).json(basketFlower);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Оновлення кількості квітки в кошику
router.put('/:userId/flowers/:flowerId', async (req, res) => {
  try {
    const { quantity } = req.body;
    const basket = await Basket.findOne({ where: { userId: req.params.userId } });
    if (!basket)
      return res.status(404).json({ message: 'Basket not found' });
    const basketFlower = await BasketFlower.findOne({
      where: { basketId: basket.id, flowerId: req.params.flowerId },
    });
    if (!basketFlower)
      return res.status(404).json({ message: 'Item not found in basket' });
    await basketFlower.update({ quantity });
    res.json(basketFlower);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Видалення квітки з кошика
router.delete('/:userId/flowers/:flowerId', async (req, res) => {
  try {
    const basket = await Basket.findOne({ where: { userId: req.params.userId } });
    if (!basket)
      return res.status(404).json({ message: 'Basket not found' });
    const deleted = await BasketFlower.destroy({
      where: { basketId: basket.id, flowerId: req.params.flowerId },
    });
    if (!deleted)
      return res.status(404).json({ message: 'Item not found in basket' });
    res.json({ message: 'Item removed from basket' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
