const express = require('express');
const router = express.Router();
const { Flower, Rating } = require('../models/models');

// Отримання списку всіх квітів
router.get('/', async (req, res) => {
  try {
    const flowers = await Flower.findAll();
    res.json(flowers);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Отримання конкретної квітки за ID
router.get('/:id', async (req, res) => {
  try {
    const flower = await Flower.findByPk(req.params.id);
    if (!flower)
      return res.status(404).json({ message: 'Flower not found' });
    res.json(flower);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Створення нової квітки
router.post('/', async (req, res) => {
  try {
    const { name, description, price, stock, imageUrl } = req.body;
    const newFlower = await Flower.create({ name, description, price, stock, imageUrl });
    res.status(201).json(newFlower);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Оновлення даних квітки
router.put('/:id', async (req, res) => {
  try {
    const { name, description, price, stock, imageUrl } = req.body;
    const flower = await Flower.findByPk(req.params.id);
    if (!flower)
      return res.status(404).json({ message: 'Flower not found' });
    await flower.update({ name, description, price, stock, imageUrl });
    res.json(flower);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Видалення квітки
router.delete('/:id', async (req, res) => {
  try {
    const flower = await Flower.findByPk(req.params.id);
    if (!flower)
      return res.status(404).json({ message: 'Flower not found' });
    await flower.destroy();
    res.json({ message: 'Flower deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Отримання рейтингів для конкретної квітки
router.get('/:id/ratings', async (req, res) => {
  try {
    const ratings = await Rating.findAll({ where: { flowerId: req.params.id } });
    res.json(ratings);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
