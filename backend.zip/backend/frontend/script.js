document.addEventListener("DOMContentLoaded", async () => {
    const response = await fetch("http://localhost:5000/products");
    const products = await response.json();

    const productList = document.getElementById("product-list");
    products.forEach(product => {
        const div = document.createElement("div");
        div.innerHTML = `<h2>${product.name}</h2><p>${product.price} грн</p>`;
        productList.appendChild(div);
    });
});

document.addEventListener("DOMContentLoaded", () => {
    fetchProducts();

    document.getElementById("search").addEventListener("input", (event) => {
        fetchProducts(event.target.value);
    });
});

function fetchProducts(query = "") {
    fetch(`/api/products?search=${query}`)
        .then(response => response.json())
        .then(products => {
            const productList = document.getElementById("product-list");
            productList.innerHTML = "";
            products.forEach(product => {
                const productCard = document.createElement("div");
                productCard.classList.add("product-card");
                productCard.innerHTML = `
                    <img src="${product.image}" alt="${product.name}">
                    <h3>${product.name}</h3>
                    <p class="price">$${product.price}</p>
                    <button onclick="addToCart(${product.id})">Додати в кошик</button>
                `;
                productList.appendChild(productCard);
            });
        })
        .catch(error => console.error("Помилка завантаження товарів:", error));
}

function addToCart(productId) {
    alert(`Товар ${productId} додано до кошика!`);
}

document.addEventListener("DOMContentLoaded", () => {
  // Отримуємо токен з localStorage
  const token = localStorage.getItem("token");
  // Отримуємо елементи навігації
  const registerLink = document.querySelector(".register-link");
  const loginLink = document.querySelector(".login-link");
  const logoutLink = document.querySelector(".logout-link");
  
  if (token) {
    // Якщо користувач авторизований, приховуємо Register та Login і показуємо Logout
    if(registerLink) registerLink.style.display = "none";
    if(loginLink) loginLink.style.display = "none";
    if(logoutLink) logoutLink.style.display = "block";
  } else {
    // Якщо користувач не авторизований, показуємо Register та Login, приховуємо Logout
    if(registerLink) registerLink.style.display = "block";
    if(loginLink) loginLink.style.display = "block";
    if(logoutLink) logoutLink.style.display = "none";
  }
  
  // Обробник виходу
  const logoutBtn = document.getElementById("logout-btn");
  if(logoutBtn) {
    logoutBtn.addEventListener("click", (e) => {
      e.preventDefault();
      localStorage.removeItem("token");
      // Перезавантаження сторінки для оновлення навігації
      window.location.reload();
    });
  }
});
